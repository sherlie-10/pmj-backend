package com.pmjsolutions.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmjBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
